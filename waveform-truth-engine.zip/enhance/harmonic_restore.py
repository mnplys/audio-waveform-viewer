import numpy as np
from scipy.signal import stft, istft

def harmonic_enhance_simple(audio, sr, strength=0.4):
    f, t, Z = stft(audio, sr)
    mag, phase = np.abs(Z), np.angle(Z)
    mag[1:] += mag[:-1] * strength * 0.05
    _, out = istft(mag * np.exp(1j * phase), sr)
    return out[:len(audio)]