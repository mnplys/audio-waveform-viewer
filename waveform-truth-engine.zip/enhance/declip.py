import numpy as np
def soft_declip(x, t=0.98):
    return np.tanh(x / t) * t