import numpy as np
from scipy.signal import stft

def landmarks(audio, sr, n_fft=2048):
    _, _, Z = stft(audio, sr, nperseg=n_fft)
    return np.abs(Z)