import argparse, librosa, soundfile as sf
from audit.landmarks import landmarks
from enhance.declip import soft_declip
from enhance.harmonic_restore import harmonic_enhance_simple

def main():
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("--out", default="output.wav")
    p.add_argument("--enhance", action="store_true")
    args = p.parse_args()

    audio, sr = librosa.load(args.input, sr=None, mono=True)
    landmarks(audio, sr)
    if args.enhance:
        audio = soft_declip(audio)
        audio = harmonic_enhance_simple(audio, sr)
    sf.write(args.out, audio, sr)

if __name__ == "__main__":
    main()